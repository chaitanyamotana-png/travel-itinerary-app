package com.example.travel_itinerary_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
